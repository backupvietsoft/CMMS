﻿namespace Vs.Support
{
    partial class frmSupport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblTEN_CT = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblRequestName = new System.Windows.Forms.Label();
            this.txtRequestName = new System.Windows.Forms.TextBox();
            this.lblID_RequestType = new System.Windows.Forms.Label();
            this.cboID_RequestType = new System.Windows.Forms.ComboBox();
            this.lblID_Priority = new System.Windows.Forms.Label();
            this.cboID_Priority = new System.Windows.Forms.ComboBox();
            this.lblEMAIL = new System.Windows.Forms.Label();
            this.txtEMAIL = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblZalo = new System.Windows.Forms.Label();
            this.txtZalo = new System.Windows.Forms.TextBox();
            this.lblUSER_NAME = new System.Windows.Forms.Label();
            this.txtUSER_NAME = new System.Windows.Forms.TextBox();
            this.lblFULL_NAME = new System.Windows.Forms.Label();
            this.txtFULL_NAME = new System.Windows.Forms.TextBox();
            this.lblTIEU_DE = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnGui = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.lblReplyContent = new System.Windows.Forms.Label();
            this.txtReplyContent = new System.Windows.Forms.TextBox();
            this.lblRequestTime = new System.Windows.Forms.Label();
            this.txtRequestTime = new System.Windows.Forms.TextBox();
            this.lblYEU_CAU_TT = new System.Windows.Forms.Label();
            this.cboYEU_CAU = new System.Windows.Forms.ComboBox();
            this.lblLINK_TL = new System.Windows.Forms.Label();
            this.txtLINK_TL = new System.Windows.Forms.TextBox();
            this.lblDUONG_DAN_TL = new System.Windows.Forms.Label();
            this.txtDUONG_DAN_TL = new System.Windows.Forms.TextBox();
            this.lblRequestContent = new System.Windows.Forms.Label();
            this.txtRequestcontent = new System.Windows.Forms.TextBox();
            this.lblVietsoftStaffName = new System.Windows.Forms.Label();
            this.txtVietsoftStaffName = new System.Windows.Forms.TextBox();
            this.lblRatingID = new System.Windows.Forms.Label();
            this.cboRatingID = new System.Windows.Forms.ComboBox();
            this.chkFinished = new System.Windows.Forms.CheckBox();
            this.txtSentTime = new System.Windows.Forms.TextBox();
            this.lblSentTime = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel1.Controls.Add(this.lblTEN_CT, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtDescription, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblDescription, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblRequestName, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.txtRequestName, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblID_RequestType, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.cboID_RequestType, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblID_Priority, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.cboID_Priority, 6, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblEMAIL, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtEMAIL, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblPhone, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtPhone, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblZalo, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtZalo, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblUSER_NAME, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtUSER_NAME, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblFULL_NAME, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtFULL_NAME, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblTIEU_DE, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 16);
            this.tableLayoutPanel1.Controls.Add(this.lblReplyContent, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.txtReplyContent, 2, 14);
            this.tableLayoutPanel1.Controls.Add(this.lblRequestTime, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.txtRequestTime, 2, 13);
            this.tableLayoutPanel1.Controls.Add(this.lblYEU_CAU_TT, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.cboYEU_CAU, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.lblLINK_TL, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.txtLINK_TL, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.lblDUONG_DAN_TL, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.txtDUONG_DAN_TL, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.lblRequestContent, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.txtRequestcontent, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.lblVietsoftStaffName, 1, 15);
            this.tableLayoutPanel1.Controls.Add(this.txtVietsoftStaffName, 2, 15);
            this.tableLayoutPanel1.Controls.Add(this.lblRatingID, 3, 15);
            this.tableLayoutPanel1.Controls.Add(this.cboRatingID, 4, 15);
            this.tableLayoutPanel1.Controls.Add(this.chkFinished, 6, 15);
            this.tableLayoutPanel1.Controls.Add(this.txtSentTime, 5, 13);
            this.tableLayoutPanel1.Controls.Add(this.lblSentTime, 4, 13);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 17;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(884, 561);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lblTEN_CT
            // 
            this.lblTEN_CT.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lblTEN_CT, 6);
            this.lblTEN_CT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTEN_CT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTEN_CT.Location = new System.Drawing.Point(11, 63);
            this.lblTEN_CT.Name = "lblTEN_CT";
            this.lblTEN_CT.Size = new System.Drawing.Size(857, 30);
            this.lblTEN_CT.TabIndex = 1;
            this.lblTEN_CT.Text = "lblCONG_TY";
            this.lblTEN_CT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDescription
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtDescription, 5);
            this.txtDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDescription.Location = new System.Drawing.Point(131, 182);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(737, 55);
            this.txtDescription.TabIndex = 7;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDescription.Location = new System.Drawing.Point(11, 179);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(114, 61);
            this.lblDescription.TabIndex = 13;
            this.lblDescription.Text = "lblDescription";
            this.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblRequestName
            // 
            this.lblRequestName.AutoSize = true;
            this.lblRequestName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRequestName.Location = new System.Drawing.Point(11, 153);
            this.lblRequestName.Name = "lblRequestName";
            this.lblRequestName.Size = new System.Drawing.Size(114, 26);
            this.lblRequestName.TabIndex = 22;
            this.lblRequestName.Text = "lblRequestName";
            this.lblRequestName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtRequestName
            // 
            this.txtRequestName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRequestName.Location = new System.Drawing.Point(131, 156);
            this.txtRequestName.Name = "txtRequestName";
            this.txtRequestName.Size = new System.Drawing.Size(162, 20);
            this.txtRequestName.TabIndex = 4;
            // 
            // lblID_RequestType
            // 
            this.lblID_RequestType.AutoSize = true;
            this.lblID_RequestType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblID_RequestType.Location = new System.Drawing.Point(299, 153);
            this.lblID_RequestType.Name = "lblID_RequestType";
            this.lblID_RequestType.Size = new System.Drawing.Size(114, 26);
            this.lblID_RequestType.TabIndex = 8;
            this.lblID_RequestType.Text = "lblID_RequestType";
            this.lblID_RequestType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboID_RequestType
            // 
            this.cboID_RequestType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboID_RequestType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboID_RequestType.FormattingEnabled = true;
            this.cboID_RequestType.Location = new System.Drawing.Point(419, 156);
            this.cboID_RequestType.Name = "cboID_RequestType";
            this.cboID_RequestType.Size = new System.Drawing.Size(162, 21);
            this.cboID_RequestType.TabIndex = 5;
            // 
            // lblID_Priority
            // 
            this.lblID_Priority.AutoSize = true;
            this.lblID_Priority.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblID_Priority.Location = new System.Drawing.Point(587, 153);
            this.lblID_Priority.Name = "lblID_Priority";
            this.lblID_Priority.Size = new System.Drawing.Size(114, 26);
            this.lblID_Priority.TabIndex = 10;
            this.lblID_Priority.Text = "lblID_Priority";
            this.lblID_Priority.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboID_Priority
            // 
            this.cboID_Priority.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboID_Priority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboID_Priority.FormattingEnabled = true;
            this.cboID_Priority.Location = new System.Drawing.Point(707, 156);
            this.cboID_Priority.Name = "cboID_Priority";
            this.cboID_Priority.Size = new System.Drawing.Size(161, 21);
            this.cboID_Priority.TabIndex = 6;
            // 
            // lblEMAIL
            // 
            this.lblEMAIL.AutoSize = true;
            this.lblEMAIL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEMAIL.Location = new System.Drawing.Point(11, 127);
            this.lblEMAIL.Name = "lblEMAIL";
            this.lblEMAIL.Size = new System.Drawing.Size(114, 26);
            this.lblEMAIL.TabIndex = 2;
            this.lblEMAIL.Text = "lblEMAIL";
            this.lblEMAIL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtEMAIL
            // 
            this.txtEMAIL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtEMAIL.Location = new System.Drawing.Point(131, 130);
            this.txtEMAIL.Name = "txtEMAIL";
            this.txtEMAIL.Size = new System.Drawing.Size(162, 20);
            this.txtEMAIL.TabIndex = 1;
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPhone.Location = new System.Drawing.Point(299, 127);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(114, 26);
            this.lblPhone.TabIndex = 3;
            this.lblPhone.Text = "lblPhone";
            this.lblPhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtPhone
            // 
            this.txtPhone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPhone.Location = new System.Drawing.Point(419, 130);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(162, 20);
            this.txtPhone.TabIndex = 2;
            this.txtPhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPhone_KeyPress);
            // 
            // lblZalo
            // 
            this.lblZalo.AutoSize = true;
            this.lblZalo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblZalo.Location = new System.Drawing.Point(587, 127);
            this.lblZalo.Name = "lblZalo";
            this.lblZalo.Size = new System.Drawing.Size(114, 26);
            this.lblZalo.TabIndex = 4;
            this.lblZalo.Text = "lblZalo";
            this.lblZalo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtZalo
            // 
            this.txtZalo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtZalo.Location = new System.Drawing.Point(707, 130);
            this.txtZalo.Name = "txtZalo";
            this.txtZalo.Size = new System.Drawing.Size(161, 20);
            this.txtZalo.TabIndex = 3;
            this.txtZalo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtZalo_KeyPress);
            // 
            // lblUSER_NAME
            // 
            this.lblUSER_NAME.AutoSize = true;
            this.lblUSER_NAME.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblUSER_NAME.Location = new System.Drawing.Point(11, 101);
            this.lblUSER_NAME.Name = "lblUSER_NAME";
            this.lblUSER_NAME.Size = new System.Drawing.Size(114, 26);
            this.lblUSER_NAME.TabIndex = 24;
            this.lblUSER_NAME.Text = "lblUSER_NAME";
            this.lblUSER_NAME.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUSER_NAME
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtUSER_NAME, 2);
            this.txtUSER_NAME.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtUSER_NAME.Location = new System.Drawing.Point(131, 104);
            this.txtUSER_NAME.Name = "txtUSER_NAME";
            this.txtUSER_NAME.ReadOnly = true;
            this.txtUSER_NAME.Size = new System.Drawing.Size(282, 20);
            this.txtUSER_NAME.TabIndex = 30;
            // 
            // lblFULL_NAME
            // 
            this.lblFULL_NAME.AutoSize = true;
            this.lblFULL_NAME.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFULL_NAME.Location = new System.Drawing.Point(419, 101);
            this.lblFULL_NAME.Name = "lblFULL_NAME";
            this.lblFULL_NAME.Size = new System.Drawing.Size(162, 26);
            this.lblFULL_NAME.TabIndex = 26;
            this.lblFULL_NAME.Text = "lblFULL_NAME";
            this.lblFULL_NAME.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtFULL_NAME
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtFULL_NAME, 2);
            this.txtFULL_NAME.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtFULL_NAME.Location = new System.Drawing.Point(587, 104);
            this.txtFULL_NAME.Name = "txtFULL_NAME";
            this.txtFULL_NAME.ReadOnly = true;
            this.txtFULL_NAME.Size = new System.Drawing.Size(281, 20);
            this.txtFULL_NAME.TabIndex = 31;
            // 
            // lblTIEU_DE
            // 
            this.lblTIEU_DE.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lblTIEU_DE, 6);
            this.lblTIEU_DE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTIEU_DE.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTIEU_DE.Location = new System.Drawing.Point(11, 8);
            this.lblTIEU_DE.Name = "lblTIEU_DE";
            this.tableLayoutPanel1.SetRowSpan(this.lblTIEU_DE, 2);
            this.lblTIEU_DE.Size = new System.Drawing.Size(857, 55);
            this.lblTIEU_DE.TabIndex = 0;
            this.lblTIEU_DE.Text = "lblTIEU_DE";
            this.lblTIEU_DE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 6);
            this.panel1.Controls.Add(this.btnGui);
            this.panel1.Controls.Add(this.btnThoat);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(11, 523);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 35);
            this.panel1.TabIndex = 29;
            // 
            // btnGui
            // 
            this.btnGui.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnGui.Location = new System.Drawing.Point(641, 0);
            this.btnGui.MaximumSize = new System.Drawing.Size(108, 34);
            this.btnGui.MinimumSize = new System.Drawing.Size(108, 34);
            this.btnGui.Name = "btnGui";
            this.btnGui.Size = new System.Drawing.Size(108, 34);
            this.btnGui.TabIndex = 18;
            this.btnGui.Text = "btnGui";
            this.btnGui.UseVisualStyleBackColor = true;
            this.btnGui.Click += new System.EventHandler(this.btnGui_Click_1);
            // 
            // btnThoat
            // 
            this.btnThoat.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnThoat.Location = new System.Drawing.Point(749, 0);
            this.btnThoat.MaximumSize = new System.Drawing.Size(108, 34);
            this.btnThoat.MinimumSize = new System.Drawing.Size(108, 34);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(108, 34);
            this.btnThoat.TabIndex = 19;
            this.btnThoat.Text = "btnThoat";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // lblReplyContent
            // 
            this.lblReplyContent.AutoSize = true;
            this.lblReplyContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReplyContent.Location = new System.Drawing.Point(11, 374);
            this.lblReplyContent.Name = "lblReplyContent";
            this.lblReplyContent.Size = new System.Drawing.Size(114, 120);
            this.lblReplyContent.TabIndex = 31;
            this.lblReplyContent.Text = "lblReplyContent";
            this.lblReplyContent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtReplyContent
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtReplyContent, 5);
            this.txtReplyContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtReplyContent.Location = new System.Drawing.Point(131, 377);
            this.txtReplyContent.Multiline = true;
            this.txtReplyContent.Name = "txtReplyContent";
            this.txtReplyContent.Size = new System.Drawing.Size(737, 114);
            this.txtReplyContent.TabIndex = 15;
            // 
            // lblRequestTime
            // 
            this.lblRequestTime.AutoSize = true;
            this.lblRequestTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRequestTime.Location = new System.Drawing.Point(11, 348);
            this.lblRequestTime.Name = "lblRequestTime";
            this.lblRequestTime.Size = new System.Drawing.Size(114, 26);
            this.lblRequestTime.TabIndex = 41;
            this.lblRequestTime.Text = "lblRequestTime";
            this.lblRequestTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtRequestTime
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtRequestTime, 2);
            this.txtRequestTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRequestTime.Location = new System.Drawing.Point(131, 351);
            this.txtRequestTime.Name = "txtRequestTime";
            this.txtRequestTime.Size = new System.Drawing.Size(282, 20);
            this.txtRequestTime.TabIndex = 12;
            // 
            // lblYEU_CAU_TT
            // 
            this.lblYEU_CAU_TT.AutoSize = true;
            this.lblYEU_CAU_TT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblYEU_CAU_TT.Location = new System.Drawing.Point(11, 322);
            this.lblYEU_CAU_TT.Name = "lblYEU_CAU_TT";
            this.lblYEU_CAU_TT.Size = new System.Drawing.Size(114, 26);
            this.lblYEU_CAU_TT.TabIndex = 17;
            this.lblYEU_CAU_TT.Text = "lblYEU_CAU_TT";
            this.lblYEU_CAU_TT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboYEU_CAU
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.cboYEU_CAU, 5);
            this.cboYEU_CAU.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboYEU_CAU.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboYEU_CAU.FormattingEnabled = true;
            this.cboYEU_CAU.Location = new System.Drawing.Point(131, 325);
            this.cboYEU_CAU.Name = "cboYEU_CAU";
            this.cboYEU_CAU.Size = new System.Drawing.Size(737, 21);
            this.cboYEU_CAU.TabIndex = 11;
            // 
            // lblLINK_TL
            // 
            this.lblLINK_TL.AutoSize = true;
            this.lblLINK_TL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLINK_TL.Location = new System.Drawing.Point(11, 296);
            this.lblLINK_TL.Name = "lblLINK_TL";
            this.lblLINK_TL.Size = new System.Drawing.Size(114, 26);
            this.lblLINK_TL.TabIndex = 46;
            this.lblLINK_TL.Text = "lblLINK_TL";
            this.lblLINK_TL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtLINK_TL
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtLINK_TL, 5);
            this.txtLINK_TL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLINK_TL.Location = new System.Drawing.Point(131, 299);
            this.txtLINK_TL.Name = "txtLINK_TL";
            this.txtLINK_TL.Size = new System.Drawing.Size(737, 20);
            this.txtLINK_TL.TabIndex = 10;
            // 
            // lblDUONG_DAN_TL
            // 
            this.lblDUONG_DAN_TL.AutoSize = true;
            this.lblDUONG_DAN_TL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDUONG_DAN_TL.Location = new System.Drawing.Point(11, 266);
            this.lblDUONG_DAN_TL.Name = "lblDUONG_DAN_TL";
            this.lblDUONG_DAN_TL.Size = new System.Drawing.Size(114, 30);
            this.lblDUONG_DAN_TL.TabIndex = 15;
            this.lblDUONG_DAN_TL.Text = "lblDUONG_DAN_TL";
            this.lblDUONG_DAN_TL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDUONG_DAN_TL
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtDUONG_DAN_TL, 5);
            this.txtDUONG_DAN_TL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDUONG_DAN_TL.Location = new System.Drawing.Point(131, 269);
            this.txtDUONG_DAN_TL.Multiline = true;
            this.txtDUONG_DAN_TL.Name = "txtDUONG_DAN_TL";
            this.txtDUONG_DAN_TL.ReadOnly = true;
            this.txtDUONG_DAN_TL.Size = new System.Drawing.Size(737, 24);
            this.txtDUONG_DAN_TL.TabIndex = 9;
            // 
            // lblRequestContent
            // 
            this.lblRequestContent.AutoSize = true;
            this.lblRequestContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRequestContent.Location = new System.Drawing.Point(11, 240);
            this.lblRequestContent.Name = "lblRequestContent";
            this.lblRequestContent.Size = new System.Drawing.Size(114, 26);
            this.lblRequestContent.TabIndex = 47;
            this.lblRequestContent.Text = "lblRequestContent";
            this.lblRequestContent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtRequestcontent
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtRequestcontent, 5);
            this.txtRequestcontent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRequestcontent.Location = new System.Drawing.Point(131, 243);
            this.txtRequestcontent.Name = "txtRequestcontent";
            this.txtRequestcontent.Size = new System.Drawing.Size(737, 20);
            this.txtRequestcontent.TabIndex = 8;
            // 
            // lblVietsoftStaffName
            // 
            this.lblVietsoftStaffName.AutoSize = true;
            this.lblVietsoftStaffName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVietsoftStaffName.Location = new System.Drawing.Point(11, 494);
            this.lblVietsoftStaffName.Name = "lblVietsoftStaffName";
            this.lblVietsoftStaffName.Size = new System.Drawing.Size(114, 26);
            this.lblVietsoftStaffName.TabIndex = 32;
            this.lblVietsoftStaffName.Text = "lblVietStaffID";
            this.lblVietsoftStaffName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtVietsoftStaffName
            // 
            this.txtVietsoftStaffName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtVietsoftStaffName.Location = new System.Drawing.Point(131, 497);
            this.txtVietsoftStaffName.Name = "txtVietsoftStaffName";
            this.txtVietsoftStaffName.Size = new System.Drawing.Size(162, 20);
            this.txtVietsoftStaffName.TabIndex = 14;
            // 
            // lblRatingID
            // 
            this.lblRatingID.AutoSize = true;
            this.lblRatingID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRatingID.Location = new System.Drawing.Point(299, 494);
            this.lblRatingID.Name = "lblRatingID";
            this.lblRatingID.Size = new System.Drawing.Size(114, 26);
            this.lblRatingID.TabIndex = 35;
            this.lblRatingID.Text = "lblRatingID";
            this.lblRatingID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboRatingID
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.cboRatingID, 2);
            this.cboRatingID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboRatingID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRatingID.FormattingEnabled = true;
            this.cboRatingID.Location = new System.Drawing.Point(419, 497);
            this.cboRatingID.Name = "cboRatingID";
            this.cboRatingID.Size = new System.Drawing.Size(282, 21);
            this.cboRatingID.TabIndex = 17;
            // 
            // chkFinished
            // 
            this.chkFinished.AutoSize = true;
            this.chkFinished.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkFinished.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkFinished.Location = new System.Drawing.Point(707, 497);
            this.chkFinished.Name = "chkFinished";
            this.chkFinished.Size = new System.Drawing.Size(161, 20);
            this.chkFinished.TabIndex = 16;
            this.chkFinished.Text = "chkFinished";
            this.chkFinished.UseVisualStyleBackColor = true;
            // 
            // txtSentTime
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtSentTime, 2);
            this.txtSentTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSentTime.Location = new System.Drawing.Point(587, 351);
            this.txtSentTime.Name = "txtSentTime";
            this.txtSentTime.Size = new System.Drawing.Size(281, 20);
            this.txtSentTime.TabIndex = 123;
            // 
            // lblSentTime
            // 
            this.lblSentTime.AutoSize = true;
            this.lblSentTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSentTime.Location = new System.Drawing.Point(419, 348);
            this.lblSentTime.Name = "lblSentTime";
            this.lblSentTime.Size = new System.Drawing.Size(162, 26);
            this.lblSentTime.TabIndex = 30;
            this.lblSentTime.Text = "lblSentTime";
            this.lblSentTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmSupport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.Controls.Add(this.tableLayoutPanel1);
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Name = "frmSupport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmSupport";
            this.Load += new System.EventHandler(this.frmSupport_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblTIEU_DE;
        private System.Windows.Forms.Label lblTEN_CT;
        private System.Windows.Forms.Label lblEMAIL;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtEMAIL;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtZalo;
        private System.Windows.Forms.Label lblID_RequestType;
        private System.Windows.Forms.ComboBox cboID_RequestType;
        private System.Windows.Forms.ComboBox cboID_Priority;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblDUONG_DAN_TL;
        private System.Windows.Forms.TextBox txtDUONG_DAN_TL;
        private System.Windows.Forms.Label lblYEU_CAU_TT;
        private System.Windows.Forms.ComboBox cboYEU_CAU;
        private System.Windows.Forms.Button btnGui;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Label lblRequestName;
        private System.Windows.Forms.TextBox txtRequestName;
        private System.Windows.Forms.Label lblUSER_NAME;
        private System.Windows.Forms.TextBox txtUSER_NAME;
        private System.Windows.Forms.Label lblFULL_NAME;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblID_Priority;
        private System.Windows.Forms.Label lblZalo;
        private System.Windows.Forms.TextBox txtFULL_NAME;
        private System.Windows.Forms.Label lblSentTime;
        private System.Windows.Forms.Label lblReplyContent;
        private System.Windows.Forms.Label lblRatingID;
        private System.Windows.Forms.Label lblVietsoftStaffName;
        private System.Windows.Forms.TextBox txtReplyContent;
        private System.Windows.Forms.Label lblRequestTime;
        private System.Windows.Forms.TextBox txtRequestTime;
        private System.Windows.Forms.ComboBox cboRatingID;
        private System.Windows.Forms.TextBox txtVietsoftStaffName;
        private System.Windows.Forms.TextBox txtSentTime;
        private System.Windows.Forms.CheckBox chkFinished;
        private System.Windows.Forms.Label lblLINK_TL;
        private System.Windows.Forms.TextBox txtLINK_TL;
        private System.Windows.Forms.Label lblRequestContent;
        private System.Windows.Forms.TextBox txtRequestcontent;
    }
}