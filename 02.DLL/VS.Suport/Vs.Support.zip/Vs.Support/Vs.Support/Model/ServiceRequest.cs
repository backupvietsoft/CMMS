﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vs.Support.Model
{
    class ServiceRequest
    {
        public Int64 ID { get; set; }
        public string RequestName { get; set; }
    }
}
