﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vs.Support.Model
{
    class Priority
    {
        public int ID { get; set; }

        public string Name { get; set; }
        public string Sign { get; set; }
    }
}
