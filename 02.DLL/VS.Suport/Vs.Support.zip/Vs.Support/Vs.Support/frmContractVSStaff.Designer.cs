﻿namespace Vs.Support
{
    partial class frmContractVSStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblContractID = new System.Windows.Forms.Label();
            this.cboContractID = new System.Windows.Forms.ComboBox();
            this.lblVSStaffID = new System.Windows.Forms.Label();
            this.cboVSStaffID = new System.Windows.Forms.ComboBox();
            this.chkVaild = new System.Windows.Forms.CheckBox();
            this.lblNote = new System.Windows.Forms.Label();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnGhi = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.Controls.Add(this.lblContractID, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.cboContractID, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblVSStaffID, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.cboVSStaffID, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.chkVaild, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblNote, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtNote, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(684, 361);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lblContractID
            // 
            this.lblContractID.AutoSize = true;
            this.lblContractID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblContractID.Location = new System.Drawing.Point(11, 8);
            this.lblContractID.Name = "lblContractID";
            this.lblContractID.Size = new System.Drawing.Size(114, 26);
            this.lblContractID.TabIndex = 0;
            this.lblContractID.Text = "lblContractID";
            this.lblContractID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboContractID
            // 
            this.cboContractID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboContractID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboContractID.FormattingEnabled = true;
            this.cboContractID.Location = new System.Drawing.Point(131, 11);
            this.cboContractID.Name = "cboContractID";
            this.cboContractID.Size = new System.Drawing.Size(136, 21);
            this.cboContractID.TabIndex = 1;
            // 
            // lblVSStaffID
            // 
            this.lblVSStaffID.AutoSize = true;
            this.lblVSStaffID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVSStaffID.Location = new System.Drawing.Point(273, 8);
            this.lblVSStaffID.Name = "lblVSStaffID";
            this.lblVSStaffID.Size = new System.Drawing.Size(114, 26);
            this.lblVSStaffID.TabIndex = 2;
            this.lblVSStaffID.Text = "lblVSStaffID";
            this.lblVSStaffID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboVSStaffID
            // 
            this.cboVSStaffID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboVSStaffID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVSStaffID.FormattingEnabled = true;
            this.cboVSStaffID.Location = new System.Drawing.Point(393, 11);
            this.cboVSStaffID.Name = "cboVSStaffID";
            this.cboVSStaffID.Size = new System.Drawing.Size(136, 21);
            this.cboVSStaffID.TabIndex = 3;
            // 
            // chkVaild
            // 
            this.chkVaild.AutoSize = true;
            this.chkVaild.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkVaild.Location = new System.Drawing.Point(535, 11);
            this.chkVaild.Name = "chkVaild";
            this.chkVaild.Size = new System.Drawing.Size(114, 20);
            this.chkVaild.TabIndex = 4;
            this.chkVaild.Text = "chkVaild";
            this.chkVaild.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkVaild.UseVisualStyleBackColor = true;
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNote.Location = new System.Drawing.Point(11, 34);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(114, 26);
            this.lblNote.TabIndex = 5;
            this.lblNote.Text = "lblNote";
            this.lblNote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNote
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtNote, 4);
            this.txtNote.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNote.Location = new System.Drawing.Point(131, 37);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(518, 20);
            this.txtNote.TabIndex = 6;
            // 
            // panel1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 5);
            this.panel1.Controls.Add(this.btnGhi);
            this.panel1.Controls.Add(this.btnThoat);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(11, 323);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(638, 35);
            this.panel1.TabIndex = 7;
            // 
            // btnGhi
            // 
            this.btnGhi.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnGhi.Location = new System.Drawing.Point(422, 0);
            this.btnGhi.Name = "btnGhi";
            this.btnGhi.Size = new System.Drawing.Size(108, 35);
            this.btnGhi.TabIndex = 1;
            this.btnGhi.Text = "btnGhi";
            this.btnGhi.UseVisualStyleBackColor = true;
            this.btnGhi.Click += new System.EventHandler(this.btnGhi_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnThoat.Location = new System.Drawing.Point(530, 0);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(108, 35);
            this.btnThoat.TabIndex = 0;
            this.btnThoat.Text = "btnThoat";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // frmContractVSStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 361);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmContractVSStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmContractVSStaff";
            this.Load += new System.EventHandler(this.frmContractVSStaff_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblContractID;
        private System.Windows.Forms.ComboBox cboContractID;
        private System.Windows.Forms.Label lblVSStaffID;
        private System.Windows.Forms.ComboBox cboVSStaffID;
        private System.Windows.Forms.CheckBox chkVaild;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnGhi;
        private System.Windows.Forms.Button btnThoat;
    }
}