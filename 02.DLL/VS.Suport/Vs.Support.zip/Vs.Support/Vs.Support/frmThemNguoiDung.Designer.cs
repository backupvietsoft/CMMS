﻿namespace Vs.Support
{
    partial class frmThemNguoiDung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblZalo = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtZalo = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.lblShortName = new System.Windows.Forms.Label();
            this.txtShortName = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblVSDeptID = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.cboVSDeptID = new System.Windows.Forms.ComboBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.chkInActive = new System.Windows.Forms.CheckBox();
            this.chkMainService = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnGhi = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.Controls.Add(this.lblFullName, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblEmail, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblZalo, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblUserName, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtFullName, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtEmail, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtZalo, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtUserName, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblShortName, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtShortName, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblPhone, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblVSDeptID, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblPassword, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtPhone, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.cboVSDeptID, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtPassword, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.chkInActive, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.chkMainService, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 7);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lblFullName
            // 
            this.lblFullName.AutoSize = true;
            this.lblFullName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFullName.Location = new System.Drawing.Point(11, 8);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(114, 30);
            this.lblFullName.TabIndex = 0;
            this.lblFullName.Text = "lblFullName";
            this.lblFullName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmail.Location = new System.Drawing.Point(11, 38);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(114, 26);
            this.lblEmail.TabIndex = 1;
            this.lblEmail.Text = "lblEmail";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblZalo
            // 
            this.lblZalo.AutoSize = true;
            this.lblZalo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblZalo.Location = new System.Drawing.Point(11, 64);
            this.lblZalo.Name = "lblZalo";
            this.lblZalo.Size = new System.Drawing.Size(114, 26);
            this.lblZalo.TabIndex = 2;
            this.lblZalo.Text = "lblZalo";
            this.lblZalo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblUserName.Location = new System.Drawing.Point(11, 90);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(114, 26);
            this.lblUserName.TabIndex = 3;
            this.lblUserName.Text = "lblUserName";
            this.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtFullName
            // 
            this.txtFullName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtFullName.Location = new System.Drawing.Point(131, 11);
            this.txtFullName.Multiline = true;
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(206, 24);
            this.txtFullName.TabIndex = 10;
            // 
            // txtEmail
            // 
            this.txtEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtEmail.Location = new System.Drawing.Point(131, 41);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(206, 20);
            this.txtEmail.TabIndex = 12;
            // 
            // txtZalo
            // 
            this.txtZalo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtZalo.Location = new System.Drawing.Point(131, 67);
            this.txtZalo.Name = "txtZalo";
            this.txtZalo.Size = new System.Drawing.Size(206, 20);
            this.txtZalo.TabIndex = 14;
            // 
            // txtUserName
            // 
            this.txtUserName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtUserName.Location = new System.Drawing.Point(131, 93);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(206, 20);
            this.txtUserName.TabIndex = 16;
            // 
            // lblShortName
            // 
            this.lblShortName.AutoSize = true;
            this.lblShortName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblShortName.Location = new System.Drawing.Point(343, 8);
            this.lblShortName.Name = "lblShortName";
            this.lblShortName.Size = new System.Drawing.Size(114, 30);
            this.lblShortName.TabIndex = 17;
            this.lblShortName.Text = "lblShortName";
            this.lblShortName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtShortName
            // 
            this.txtShortName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtShortName.Location = new System.Drawing.Point(463, 11);
            this.txtShortName.Multiline = true;
            this.txtShortName.Name = "txtShortName";
            this.txtShortName.Size = new System.Drawing.Size(206, 24);
            this.txtShortName.TabIndex = 18;
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPhone.Location = new System.Drawing.Point(343, 38);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(114, 26);
            this.lblPhone.TabIndex = 19;
            this.lblPhone.Text = "lblPhone";
            this.lblPhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblVSDeptID
            // 
            this.lblVSDeptID.AutoSize = true;
            this.lblVSDeptID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVSDeptID.Location = new System.Drawing.Point(343, 64);
            this.lblVSDeptID.Name = "lblVSDeptID";
            this.lblVSDeptID.Size = new System.Drawing.Size(114, 26);
            this.lblVSDeptID.TabIndex = 20;
            this.lblVSDeptID.Text = "lblVSDeptID";
            this.lblVSDeptID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPassword.Location = new System.Drawing.Point(343, 90);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(114, 26);
            this.lblPassword.TabIndex = 21;
            this.lblPassword.Text = "lblPassword";
            this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtPhone
            // 
            this.txtPhone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPhone.Location = new System.Drawing.Point(463, 41);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(206, 20);
            this.txtPhone.TabIndex = 22;
            // 
            // cboVSDeptID
            // 
            this.cboVSDeptID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboVSDeptID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVSDeptID.FormattingEnabled = true;
            this.cboVSDeptID.Location = new System.Drawing.Point(463, 67);
            this.cboVSDeptID.Name = "cboVSDeptID";
            this.cboVSDeptID.Size = new System.Drawing.Size(206, 21);
            this.cboVSDeptID.TabIndex = 23;
            // 
            // txtPassword
            // 
            this.txtPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPassword.Location = new System.Drawing.Point(463, 93);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(206, 20);
            this.txtPassword.TabIndex = 24;
            this.txtPassword.UseSystemPasswordChar = true;
            // 
            // chkInActive
            // 
            this.chkInActive.AutoSize = true;
            this.chkInActive.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkInActive.Location = new System.Drawing.Point(675, 11);
            this.chkInActive.Name = "chkInActive";
            this.chkInActive.Size = new System.Drawing.Size(114, 24);
            this.chkInActive.TabIndex = 25;
            this.chkInActive.Text = "chkInActive";
            this.chkInActive.UseVisualStyleBackColor = true;
            // 
            // chkMainService
            // 
            this.chkMainService.AutoSize = true;
            this.chkMainService.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkMainService.Location = new System.Drawing.Point(675, 41);
            this.chkMainService.Name = "chkMainService";
            this.chkMainService.Size = new System.Drawing.Size(114, 20);
            this.chkMainService.TabIndex = 26;
            this.chkMainService.Text = "chkMainService";
            this.chkMainService.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 5);
            this.panel1.Controls.Add(this.btnGhi);
            this.panel1.Controls.Add(this.btnThoat);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(11, 412);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 35);
            this.panel1.TabIndex = 27;
            // 
            // btnGhi
            // 
            this.btnGhi.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnGhi.Location = new System.Drawing.Point(562, 0);
            this.btnGhi.Name = "btnGhi";
            this.btnGhi.Size = new System.Drawing.Size(108, 35);
            this.btnGhi.TabIndex = 1;
            this.btnGhi.Text = "btnGhi";
            this.btnGhi.UseVisualStyleBackColor = true;
            this.btnGhi.Click += new System.EventHandler(this.btnGhi_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnThoat.Location = new System.Drawing.Point(670, 0);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(108, 35);
            this.btnThoat.TabIndex = 0;
            this.btnThoat.Text = "btnThoat";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // frmThemNguoiDung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmThemNguoiDung";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmThemNguoiDung";
            this.Load += new System.EventHandler(this.frmThemNguoiDung_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblZalo;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtZalo;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label lblShortName;
        private System.Windows.Forms.TextBox txtShortName;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblVSDeptID;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.ComboBox cboVSDeptID;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.CheckBox chkInActive;
        private System.Windows.Forms.CheckBox chkMainService;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnGhi;
        private System.Windows.Forms.Button btnThoat;
    }
}