﻿namespace Vs.Support
{
    partial class frmCustomer_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblTenCTY_FullName = new System.Windows.Forms.Label();
            this.lblShortName = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblCEO = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtTenCT_FullName = new System.Windows.Forms.TextBox();
            this.txtShortName = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtCEO = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnGhi = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabTTLienHe = new System.Windows.Forms.TabPage();
            this.dgvContact = new System.Windows.Forms.DataGridView();
            this.lblGHI_CHU = new System.Windows.Forms.Label();
            this.txtGHI_CHU = new System.Windows.Forms.TextBox();
            this.lblHDBT_DA_KY = new System.Windows.Forms.Label();
            this.txtHDBT_DA_KY = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabTTLienHe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContact)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.Controls.Add(this.lblTenCTY_FullName, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblShortName, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblAddress, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblCEO, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblEmail, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblPhone, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtTenCT_FullName, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtShortName, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtAddress, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtCEO, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtEmail, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtPhone, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblGHI_CHU, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtGHI_CHU, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblHDBT_DA_KY, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtHDBT_DA_KY, 2, 5);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lblTenCTY_FullName
            // 
            this.lblTenCTY_FullName.AutoSize = true;
            this.lblTenCTY_FullName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTenCTY_FullName.Location = new System.Drawing.Point(11, 28);
            this.lblTenCTY_FullName.Name = "lblTenCTY_FullName";
            this.lblTenCTY_FullName.Size = new System.Drawing.Size(114, 26);
            this.lblTenCTY_FullName.TabIndex = 0;
            this.lblTenCTY_FullName.Text = "lblTenCTY_FullName";
            this.lblTenCTY_FullName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblShortName
            // 
            this.lblShortName.AutoSize = true;
            this.lblShortName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblShortName.Location = new System.Drawing.Point(403, 28);
            this.lblShortName.Name = "lblShortName";
            this.lblShortName.Size = new System.Drawing.Size(114, 26);
            this.lblShortName.TabIndex = 1;
            this.lblShortName.Text = "lblShortName";
            this.lblShortName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAddress.Location = new System.Drawing.Point(11, 54);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(114, 26);
            this.lblAddress.TabIndex = 2;
            this.lblAddress.Text = "lblAddress";
            this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCEO
            // 
            this.lblCEO.AutoSize = true;
            this.lblCEO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCEO.Location = new System.Drawing.Point(403, 54);
            this.lblCEO.Name = "lblCEO";
            this.lblCEO.Size = new System.Drawing.Size(114, 26);
            this.lblCEO.TabIndex = 3;
            this.lblCEO.Text = "lblCEO";
            this.lblCEO.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmail.Location = new System.Drawing.Point(11, 80);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(114, 26);
            this.lblEmail.TabIndex = 4;
            this.lblEmail.Text = "lblEmail";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPhone.Location = new System.Drawing.Point(403, 80);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(114, 26);
            this.lblPhone.TabIndex = 5;
            this.lblPhone.Text = "lblPhone";
            this.lblPhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTenCT_FullName
            // 
            this.txtTenCT_FullName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTenCT_FullName.Location = new System.Drawing.Point(131, 31);
            this.txtTenCT_FullName.Name = "txtTenCT_FullName";
            this.txtTenCT_FullName.Size = new System.Drawing.Size(266, 20);
            this.txtTenCT_FullName.TabIndex = 1;
            // 
            // txtShortName
            // 
            this.txtShortName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtShortName.Location = new System.Drawing.Point(523, 31);
            this.txtShortName.Name = "txtShortName";
            this.txtShortName.Size = new System.Drawing.Size(266, 20);
            this.txtShortName.TabIndex = 2;
            // 
            // txtAddress
            // 
            this.txtAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAddress.Location = new System.Drawing.Point(131, 57);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(266, 20);
            this.txtAddress.TabIndex = 3;
            // 
            // txtCEO
            // 
            this.txtCEO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCEO.Location = new System.Drawing.Point(523, 57);
            this.txtCEO.Name = "txtCEO";
            this.txtCEO.Size = new System.Drawing.Size(266, 20);
            this.txtCEO.TabIndex = 4;
            // 
            // txtEmail
            // 
            this.txtEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtEmail.Location = new System.Drawing.Point(131, 83);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(266, 20);
            this.txtEmail.TabIndex = 5;
            // 
            // txtPhone
            // 
            this.txtPhone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPhone.Location = new System.Drawing.Point(523, 83);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(266, 20);
            this.txtPhone.TabIndex = 6;
            // 
            // panel1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 4);
            this.panel1.Controls.Add(this.btnGhi);
            this.panel1.Controls.Add(this.btnThoat);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(11, 412);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 35);
            this.panel1.TabIndex = 12;
            // 
            // btnGhi
            // 
            this.btnGhi.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnGhi.Location = new System.Drawing.Point(562, 0);
            this.btnGhi.Name = "btnGhi";
            this.btnGhi.Size = new System.Drawing.Size(108, 35);
            this.btnGhi.TabIndex = 11;
            this.btnGhi.Text = "btnGhi";
            this.btnGhi.UseVisualStyleBackColor = true;
            this.btnGhi.Click += new System.EventHandler(this.btnGhi_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnThoat.Location = new System.Drawing.Point(670, 0);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(108, 35);
            this.btnThoat.TabIndex = 12;
            this.btnThoat.Text = "btnThoat";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // tabControl1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tabControl1, 4);
            this.tabControl1.Controls.Add(this.tabTTLienHe);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(11, 187);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(778, 219);
            this.tabControl1.TabIndex = 9;
            // 
            // tabTTLienHe
            // 
            this.tabTTLienHe.Controls.Add(this.dgvContact);
            this.tabTTLienHe.Location = new System.Drawing.Point(4, 22);
            this.tabTTLienHe.Name = "tabTTLienHe";
            this.tabTTLienHe.Padding = new System.Windows.Forms.Padding(3);
            this.tabTTLienHe.Size = new System.Drawing.Size(770, 193);
            this.tabTTLienHe.TabIndex = 0;
            this.tabTTLienHe.Text = "tabTTLienHe";
            this.tabTTLienHe.UseVisualStyleBackColor = true;
            // 
            // dgvContact
            // 
            this.dgvContact.AllowUserToDeleteRows = false;
            this.dgvContact.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvContact.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContact.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvContact.Location = new System.Drawing.Point(3, 3);
            this.dgvContact.Name = "dgvContact";
            this.dgvContact.Size = new System.Drawing.Size(764, 187);
            this.dgvContact.TabIndex = 10;
            this.dgvContact.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvContact_KeyDown);
            // 
            // lblGHI_CHU
            // 
            this.lblGHI_CHU.AutoSize = true;
            this.lblGHI_CHU.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGHI_CHU.Location = new System.Drawing.Point(11, 132);
            this.lblGHI_CHU.Name = "lblGHI_CHU";
            this.lblGHI_CHU.Size = new System.Drawing.Size(114, 52);
            this.lblGHI_CHU.TabIndex = 13;
            this.lblGHI_CHU.Text = "lblGHI_CHU";
            this.lblGHI_CHU.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGHI_CHU
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtGHI_CHU, 3);
            this.txtGHI_CHU.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGHI_CHU.Location = new System.Drawing.Point(131, 135);
            this.txtGHI_CHU.Multiline = true;
            this.txtGHI_CHU.Name = "txtGHI_CHU";
            this.txtGHI_CHU.Size = new System.Drawing.Size(658, 46);
            this.txtGHI_CHU.TabIndex = 8;
            // 
            // lblHDBT_DA_KY
            // 
            this.lblHDBT_DA_KY.AutoSize = true;
            this.lblHDBT_DA_KY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblHDBT_DA_KY.Location = new System.Drawing.Point(11, 106);
            this.lblHDBT_DA_KY.Name = "lblHDBT_DA_KY";
            this.lblHDBT_DA_KY.Size = new System.Drawing.Size(114, 26);
            this.lblHDBT_DA_KY.TabIndex = 15;
            this.lblHDBT_DA_KY.Text = "lblHDBT_DA_KY";
            this.lblHDBT_DA_KY.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtHDBT_DA_KY
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtHDBT_DA_KY, 3);
            this.txtHDBT_DA_KY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtHDBT_DA_KY.Location = new System.Drawing.Point(131, 109);
            this.txtHDBT_DA_KY.Name = "txtHDBT_DA_KY";
            this.txtHDBT_DA_KY.Size = new System.Drawing.Size(658, 20);
            this.txtHDBT_DA_KY.TabIndex = 7;
            // 
            // frmCustomer_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmCustomer_View";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmCustomer_View";
            this.Load += new System.EventHandler(this.frmCustomer_View_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabTTLienHe.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContact)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblTenCTY_FullName;
        private System.Windows.Forms.Label lblShortName;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblCEO;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtTenCT_FullName;
        private System.Windows.Forms.TextBox txtShortName;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtCEO;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnGhi;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabTTLienHe;
        private System.Windows.Forms.DataGridView dgvContact;
        private System.Windows.Forms.Label lblGHI_CHU;
        private System.Windows.Forms.TextBox txtGHI_CHU;
        private System.Windows.Forms.Label lblHDBT_DA_KY;
        private System.Windows.Forms.TextBox txtHDBT_DA_KY;
    }
}