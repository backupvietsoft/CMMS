﻿using System.Windows.Forms;

namespace Vs.Support
{
    public partial class TEST : Form
    {
        public TEST()
        {
            InitializeComponent();
        }
    }
}
